(ns task02.helpers)

(defn parse-int [int-str]
  (Integer/parseInt int-str))
